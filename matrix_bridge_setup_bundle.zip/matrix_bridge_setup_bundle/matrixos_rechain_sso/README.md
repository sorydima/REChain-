
# REChain SSO Integration

Provides OpenID Connect-compatible login to MatrixOS with REChain ID.
