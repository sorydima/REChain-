
# Matrix Ultimate on DockerHub
This container includes docker-compose setup to run full Matrix bundle.

## Usage
```bash
docker run -v /opt/matrix:/opt/matrix youruser/matrix-ultimate
```
