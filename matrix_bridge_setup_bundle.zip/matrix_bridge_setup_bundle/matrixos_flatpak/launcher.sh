#!/bin/bash
docker-compose -f /opt/matrix/docker-compose.yml up -d
